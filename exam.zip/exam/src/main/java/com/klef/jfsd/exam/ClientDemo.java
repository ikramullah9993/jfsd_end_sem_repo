package com.klef.jfsd.exam;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class ClientDemo {
    public static void main(String[] args) {
        Session session = HibernateUtil.getSessionFactory().openSession();

        try {
            // Insert operation
            Transaction insertTransaction = session.beginTransaction();

            Car car = new Car();
            car.setName("Toyota Corolla");
            car.setType("Sedan");
            car.setMaxSpeed(180);
            car.setColor("Red");
            car.setNumberOfDoors(4);

            Truck truck = new Truck();
            truck.setName("Volvo FH");
            truck.setType("Heavy Duty");
            truck.setMaxSpeed(120);
            truck.setColor("Blue");
            truck.setLoadCapacity(20000);

            // Save objects
            session.persist(car);
            session.persist(truck);

            insertTransaction.commit();
            System.out.println("Records inserted successfully!");

            
            Transaction fetchTransaction = session.beginTransaction();

          
            Car fetchedCar = session.get(Car.class, 1); 
            if (fetchedCar != null) {
                System.out.println("Car Details: " + fetchedCar.getName() + ", " + fetchedCar.getColor());
            } else {
                System.out.println("Car with ID 1 not found.");
            }

            // Fetching Truck
            Truck fetchedTruck = session.get(Truck.class, 2); 
            if (fetchedTruck != null) {
                System.out.println("Truck Details: " + fetchedTruck.getName() + ", " + fetchedTruck.getLoadCapacity());
            } else {
                System.out.println("Truck with ID 2 not found.");
            }

            fetchTransaction.commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
    }
}
